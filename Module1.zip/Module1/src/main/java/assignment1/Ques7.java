package assignment1;

import java.util.Scanner;

public class Ques7 {

	public static void main(String[] args) {
Scanner no=new Scanner(System.in);
System.out.println("Enter the number :");
int a=no.nextInt();
for(int i=1;i<=10;i++){
	System.out.println(a+"x"+i+"="+a*i);
}
	}

}
