package assignment1;

public class Ques2 {

	public static void main(String[] args) {
int a,b;
a=100;
b=50;
System.out.println(a+b);
	}

}
