package assignment1;

import java.util.Scanner;

public class Ques6 {

	public static void main(String[] args) {
Scanner no=new Scanner(System.in);
System.out.println("Enter two numbers :- ");
int a=no.nextInt();
int b=no.nextInt();
System.out.println(a+"+"+b+"="+(a+b));
System.out.println(a+"-"+b+"="+(a-b));
System.out.println(a+"*"+b+"="+(a*b));
System.out.println(a+"/"+b+"="+(a/b));
System.out.println(a+"mod"+b+"="+(a%b));

	}

}
