package assignment1;

import java.util.Scanner;

public class Ques5 {

	public static void main(String[] args) {
Scanner no=new Scanner(System.in);
System.out.println("Enter the 1st number : ");
int a=no.nextInt();
System.out.println("Enter the 2st number : ");
int b=no.nextInt();
System.out.println(a+"x"+b+"="+a*b);
	}

}
