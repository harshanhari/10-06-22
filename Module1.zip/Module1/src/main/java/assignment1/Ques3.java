package assignment1;

public class Ques3 {

	public static void main(String[] args) {
	int a=30,b=6;
	System.out.println(a/b);
	}

}
