package operaters;

public class Example13 {

	public static void main(String[] args) {
int a=10;
a+=3;
System.out.println(a);
a-=4;
System.out.println(a);
a*=2;
System.out.println(a);
a/=2;
System.out.println(a);
	}

}
