package operaters;

public class Example14 {

	public static void main(String[] args) {
short a=10;
short b=10;
a=(short) (a+b);
System.out.println(a);

	}

}
