package operaters;

public class Example1 {

	public static void main(String[] args) {
	int a=10;
	System.out.println(a++);
	System.out.println(++a);
	System.out.println(a--);
	System.out.println(--a);
			

	}

}
