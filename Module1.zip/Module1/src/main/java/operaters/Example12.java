package operaters;

public class Example12 {

	public static void main(String[] args) {
int a=10,b=20;
a+=4;
b-=4;
System.out.println(a);
System.out.println(b);

	}

}
