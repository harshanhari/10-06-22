package pack1;

public class Example2 {

	public static void main(String[] args) {
		float a=10.5f;
		int b=(int) a;
		System.out.println(a+","+b);
	}

}
