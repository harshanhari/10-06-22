package pack1;

public class Student {
	public static void main(String arg[]) {
		
		System.out.println("Welcome");
		
	}

}
