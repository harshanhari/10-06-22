package pack1;

public class Simple {
	
	
	
public static void main(String arg[])
{
int a=1000000000;
float b=20555555555555555555555555555555555555.3252566666666666666666666666666666666666666666666666666666666666666666666666565555555555f;
boolean c=false;
short d=12355;
long e=1222222222222222222l;
double f=12355555555555555.21;
char g='N';
String n="name";
byte h=54;

System.out.println(a);
}                                   		
}
