package scannerex;

import java.util.*;
public class Scanner1 {

	public static void main(String[] args) {

		
		Scanner sc=new Scanner(System.in);
		Scanner scs=new Scanner(System.in);

		System.out.println("Enter your name");
		String name=sc.nextLine();
		//System.out.println("Your name is "+name);
		System.out.println("Enter  your age ");
		int age=scs.nextInt();
		//System.out.println("Your age is "+age);
		System.out.println("Enter your address");
		String address=sc.nextLine();
		System.out.println(name+" "+age+" "+address);
	}

}
