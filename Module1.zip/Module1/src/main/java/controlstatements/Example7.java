package controlstatements;

public class Example7 {

	public static void main(String[] args) {
int n=13;
if(n%2==0) {
	System.out.println("number is even");
}
	else{
		System.out.println("odd");
	}

	}

}
