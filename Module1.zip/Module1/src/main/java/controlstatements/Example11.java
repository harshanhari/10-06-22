package controlstatements;

public class Example11 {

	public static void main(String[] args) {
int num=13;
if(num>0) {
	System.out.println("POSITIVE");
}
else if(num<0) {
	System.out.println("NEGATIVE");
}
else {
	System.out.println("ZERO");
}
	}

}
