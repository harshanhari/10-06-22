package controlstatements;

public class Example12 {

	public static void main(String[] args) {
int age=20,weight=80;
if(age>=18) {
	if(weight>50) {
		System.out.println("you are eligible for donation");
	}
}
	}

}
