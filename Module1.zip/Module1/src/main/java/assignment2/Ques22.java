package assignment2;

import java.util.Scanner;

public class Ques22 {

	public static void main(String[] args) {
		Scanner number=new Scanner(System.in);
		System.out.println("Enter the limit");
		int n=number.nextInt();
		int a = 1;
        for (int i=1;i<=n;i++) {
            for (int j=1;j<=i;j++) {
                System.out.print(a++ +" ");
            }
            System.out.println();
        }
	}
	
}
