package assignment2;

import java.util.Scanner;

public class Ques3 {

	public static void main(String[] args) {
Scanner yr=new Scanner(System.in);
System.out.println("Enter the year");
int y=yr.nextInt();
if(y%4==0) {
	System.out.println("Leap Year");
}
else {
	System.out.println("not a leap year");
}
	}

}
