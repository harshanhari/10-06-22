package assignment2;

import java.util.Scanner;

public class Ques21 {

	public static void main(String[] args) {
Scanner number=new Scanner(System.in);
System.out.println("enter the number");
int n=number.nextInt();
int codd=0,ceven=0,sodd=0,seven=0,oddavg,evenavg;
while(n>0) {
	if(n%2==0) {
		seven=seven+n;
		ceven++;
	}
	else {
		sodd=sodd+n;
		codd++;
	}
	n--;
}
oddavg=sodd/codd;
evenavg=seven/ceven;
System.out.println("Odd avarage is "+oddavg);
System.out.println("Even avarage is "+evenavg);
	}

}
