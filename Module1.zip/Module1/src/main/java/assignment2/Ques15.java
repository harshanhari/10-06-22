package assignment2;

public class Ques15 {

	public static void main(String[] args) {
int a=0,i;
for(i=100;i<200;i++) {
	if(i%7==0) {
		a=a+i;
	}
}
System.out.println(""+a);

	}

}
