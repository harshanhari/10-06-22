package assignment2;

import java.util.Scanner;

public class Ques14 {

	public static void main(String[] args) {
Scanner pal=new Scanner(System.in);
System.out.print("Enter a number ");
int n=pal.nextInt();
int temp,rev,a=0;    
temp=n;    
while(n>0){    
 rev=n%10;
 a=(a*10)+rev;    
 n=n/10;    
}    
if(temp==a)    
 System.out.println("palindrome number ");    
else    
 System.out.println("not palindrome");    
	}

}
