package assignment2;

import java.util.Scanner;

public class Ques2 {

	public static void main(String[] args) {
Scanner no=new Scanner(System.in);
System.out.println("Enter the number :");
int a=no.nextInt();
int b=no.nextInt();
if(a==b) {
	System.out.println("the numbers are equal");
}
else {
	System.out.println("the numbers are not equal");
}

	}

}
