package assignment2;

public class Ques13 {

	public static void main(String[] args) {
		int a;
for(int i=1;i<=100;i++) {
	a=0;
	for(int j=2;j<=i/2;j++) {
		if(i%j==0) {
			a++;
			break;
		}
	}
	if(a==0) {
		System.out.println(i);
	}
	}
	}
}

