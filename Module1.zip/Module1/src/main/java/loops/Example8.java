package loops;

public class Example8 {

	public static void main(String[] args) {
		for(;;){
			System.out.println("infinite");// TODO Auto-generated method stub
		}

	}

}
